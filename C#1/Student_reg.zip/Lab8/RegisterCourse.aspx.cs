﻿using Lab8.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab8
{
    public partial class RegisterCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<Course> availableCourses = Helper.GetAvailableCourses();
                foreach (Course c in availableCourses)
                {
                    CheckBoxListCourses.Items.Add(new ListItem($"{c.Title} - {c.WeeklyHours} hours/week", c.Code));
                }

                // Load students into the DropDownList from the session.
                var students = Session["Students"] as List<Student>;
                if (students != null)
                {
                    ddlStudents.Items.Clear(); // Clear existing items

                    // Add default item
                    ddlStudents.Items.Add(new ListItem("--Select Student--", ""));

                    // Add students to the dropdown list
                    foreach (var student in students)
                    {
                        string studentText = $"{student.Id} - {student.Name} ({student.StudentType})";
                        ListItem item = new ListItem(studentText, student.Id.ToString());
                        ddlStudents.Items.Add(item);
                    }
                }
            }
        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Clear any previous error messages.
                LabelError.Visible = false;
                LabelError.Text = "";

                // Initially hide the confirmation panel in case of errors.
                PanelConfirmation.Visible = false;



                // Retrieve the student type from the DropDownList (assuming there's a DropDownList for it)
                string studentType = Session["SelectedStudentType"] as string;

                // Calculate the selected hours and count the selected courses.
                List<Course> selectedCourses = CheckBoxListCourses.Items.Cast<ListItem>()
                    .Where(li => li.Selected)
                    .Select(li => Helper.GetCourseByCode(li.Value))
                    .ToList();

                int selectedHours = selectedCourses.Sum(c => c.WeeklyHours);
                int selectedCoursesCount = selectedCourses.Count;

                // Validate that at least one course has been selected.
                if (selectedCoursesCount == 0)
                {
                    LabelError.Visible = true;
                    LabelError.Text = "Please select at least one course.";
                    return;
                }

                // Perform validation based on student type
                bool isValid = ValidateStudentSelection(studentType, selectedHours, selectedCoursesCount);


                if (isValid)
                {
                    int studentId = Convert.ToInt32(ddlStudents.SelectedValue);
                    Student student = GetStudentById(studentId); // Implement this method to retrieve the student.
                    student.RegisterCourses(selectedCourses); // Assuming RegisterCourses is a method on the Student object.

                    ShowConfirmation();

                    // Confirmation message
                    LabelConfirmation.Text = $"Selected student has registered {selectedCourses.Count} course(s), {selectedHours} hours weekly";

                    // Make the confirmation panel visible
                    PanelConfirmation.Visible = true;

                    // Hide the course registration checkbox list
                    CheckBoxListCourses.Visible = true;

                    // Optionally, add the courses to the confirmation table
                    foreach (var course in selectedCourses)
                    {
                        TableRow newRow = new TableRow();
                        newRow.Cells.Add(new TableCell { Text = course.Code });
                        newRow.Cells.Add(new TableCell { Text = course.Title });
                        newRow.Cells.Add(new TableCell { Text = $"{course.WeeklyHours} hours/week" });
                        TableCourses.Rows.Add(newRow);
                    }

                }
                else
                {
                    LabelError.Visible = true;
                    LabelError.Text = "Course Selection is not correct. Please review your course selections.";
                }
            }
            catch (Exception ex)
            {
                // Display the error message from the exception
                LabelError.Visible = true;
                LabelError.Text = ex.Message;
            }
        }
        private Student GetStudentById(int id)
        {
            // Replace this with the actual code to access your student data source, e.g., a session or database
            var students = HttpContext.Current.Session["Students"] as List<Student>;
            return students?.FirstOrDefault(s => s.Id == id);
        }

        private void ShowConfirmation()
        {
            // Clear any existing rows from the table if you have it in your aspx page
            TableCourses.Rows.Clear();

            // Get the selected student
            int studentId = Convert.ToInt32(ddlStudents.SelectedValue);
            Student selectedStudent = GetStudentById(studentId); // Implement GetStudentById method to fetch a student

            if (selectedStudent != null)
            {
                int selectedHours = selectedStudent.RegisteredCourses.Sum(course => course.WeeklyHours);
                int selectedCoursesCount = selectedStudent.RegisteredCourses.Count;

                // Show only the summary without detailed course list
                LabelConfirmation.Text = $"Selected student has registered {selectedCoursesCount} course(s), {selectedHours} hours weekly";

                // If you have a label for total weekly hours and you want to remove it, do it like this:
                LabelTotalHours.Visible = false;

                // Update the panel to only show the confirmation message
                PanelConfirmation.Visible = true;
            }
        }

        protected void ddlStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateRegistrationSummary();
            ShowConfirmation(); // Refresh the confirmation panel with new details
        }

        private void UpdateRegistrationSummary()
        {
            // Get the selected student and update the registration summary
            int studentId = Convert.ToInt32(ddlStudents.SelectedValue);
            Student selectedStudent = GetStudentById(studentId); // Implement GetStudentById method to fetch a student

            // Update the CheckBoxList to reflect the courses the student is registered for
            // This assumes your courses have unique identifiers that match with CheckBoxList items
            foreach (ListItem item in CheckBoxListCourses.Items)
            {
                item.Selected = selectedStudent.RegisteredCourses.Any(course => course.Code == item.Value);
            }

        }
        private bool ValidateStudentSelection(string studentType, int selectedHours, int selectedCoursesCount)
        {
            // validation logic here
            // Return true if valid, false otherwise
            return true; // Placeholder return value


        }
    }

}