﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab8.Models
{
    public class Student
    {
        public int Id { get; set;}
        public string Name { get; set; }
        public List<Course> RegisteredCourses { get; } = new List<Course>();// Readonly property

        public string StudentType { get; set; } // This should be set when the student is created

        public Student(string name)
        {
            Id = new Random().Next(100000, 999999);
            Name = name;
        }

        // Virtual method to register courses
        public virtual void RegisterCourses(List<Course> selectedCourses)
        {
            RegisteredCourses.Clear(); // Remove all elements from RegisteredCourses
            foreach (var course in selectedCourses)
            {
                RegisteredCourses.Add(course); // Add the selectedCourses to RegisteredCourses
            }
        }

        // Method to calculate total weekly hours
        public int TotalWeeklyHours()
        {
            return RegisteredCourses.Sum(course => course.WeeklyHours); // Assuming Course has a WeeklyHours property
        }
        public string FormattedName => Name; // Or any other formatting
    }
}