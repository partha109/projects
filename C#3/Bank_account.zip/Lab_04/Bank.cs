﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Lab_04
{
    internal class Bank
    {
        static void Main(string[] args)
        {
            List<Account> accounts = new List<Account>();
            int months = 0;
            bool inputValid = false;

            while (!inputValid)
            {
                try
                {
                    Console.Write("Enter the number of months to deposit (must be a positive number): ");
                    months = Convert.ToInt32(Console.ReadLine());
                    if (months > 0) inputValid = true;
                    else Console.WriteLine("The number of months must be greater than zero.");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
            }

            Console.WriteLine();

            while (true)
            {
                string name = PromptForValidName("Enter Customer's Name or press ENTER to finish: ");
                if (string.IsNullOrWhiteSpace(name)) break;

                decimal initialDeposit = PromptForDecimal("initial deposit", Account.MinimumInitialBalance);
                decimal monthlyDeposit = PromptForDecimal("monthly deposit", Account.MinimumMonthlyDeposit);

                Console.WriteLine();

                Account newAccount = new Account(name, initialDeposit, monthlyDeposit);
                accounts.Add(newAccount);
            }
            static string PromptForValidName(string message)
            {
                string input;
                bool isValid;
                do
                {
                    Console.Write(message);
                    input = Console.ReadLine();
                    isValid = Regex.IsMatch(input, @"^[a-zA-Z\s]*$") && !string.IsNullOrWhiteSpace(input);
                    if (!isValid) Console.WriteLine("Invalid input. Please enter a valid name with alphabets only.");
                } while (!isValid && !string.IsNullOrWhiteSpace(input));

                return input;
            }

            Console.WriteLine();

            foreach (Account account in accounts)
            {
                account.UpdateBalanceForMonths(months);
                Console.WriteLine($"After {months} month(s), {account.OwnerName}'s account (#{account.AccountNumber}), has a balance of: {account.Balance:C2}");
            }

            Console.WriteLine();

            Console.WriteLine("Press Enter to complete");

            Console.ReadLine();
        }

        static decimal PromptForDecimal(string depositType, decimal minimumAmount)
        {
            decimal amount;
            bool validInput = false;

            do
            {
                try
                {
                    Console.Write($"Enter the customer's {depositType} Amount (minimum {minimumAmount:C2}): ");
                    amount = Convert.ToDecimal(Console.ReadLine());
                    if (amount >= minimumAmount) validInput = true;
                    else Console.WriteLine($"The {depositType} amount must be at least {minimumAmount:C2}.");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a valid monetary amount.");
                    amount = -1;
                }
            } while (!validInput);

            return amount;
        }
    } 
}
