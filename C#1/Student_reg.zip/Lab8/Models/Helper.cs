﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab8.Models
{
    public static class Helper
    {
        public static List<Course> GetAvailableCourses()
        {
            List<Course> courses = new List<Course>();

            courses.Add(new Course("CST8282", "Introduction to Database Systems", 4));
            courses.Add(new Course("CST8253", "Web Programming II", 2));
            courses.Add(new Course("CST8256", "Web Programming Language I", 5));
            courses.Add(new Course("CST8255", "Web Imaging and Animations", 2));
            courses.Add(new Course("CST8254", "Network Operating System", 1));
            courses.Add(new Course("CST2200", "Data Warehouse Design", 3));
            courses.Add(new Course("CST2240", "Advance Database topics", 1));

            return courses;
        }

        public static Course GetCourseByCode(string code)
        {
            return GetAvailableCourses().FirstOrDefault(c => c.Code == code);
        }
    }
}