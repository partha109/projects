﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab8.Models
{
    public class FulltimeStudent : Student
    {
        public static int MaxWeeklyHours { get; set; }

        public FulltimeStudent(string name) : base(name) { }

        public override void RegisterCourses(List<Course> selectedCourses)
        {
            if (selectedCourses.Sum(course => course.WeeklyHours) > MaxWeeklyHours)
            {
                throw new Exception("Your selection exceeds the maximum weekly hours for fulltime student: 16 hrs");
            }
            base.RegisterCourses(selectedCourses);
        }
        public override string ToString()
        {
            return $"{Id} – {Name} (Full time)";
        }
    }
}