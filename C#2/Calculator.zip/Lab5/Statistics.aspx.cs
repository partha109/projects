﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            // Initialize the variables to avoid use of unassigned local variable error.
            double num1 = 0, num2 = 0, num3 = 0;

            bool isValidInput = double.TryParse(TextBoxNum1.Text, out num1) &&
                                double.TryParse(TextBoxNum2.Text, out num2) &&
                                double.TryParse(TextBoxNum3.Text, out num3);
            
            if (isValidInput)
            {
                // Calculate statistics
                double sum = num1 + num2 + num3;
                double average = sum / 3;
                double[] numbers = new double[] { num1, num2, num3 };
                double max = numbers.Max();
                double min = numbers.Min();

                // Display results
                MaximumLabel.Text = $"{max}";
                MinimumLabel.Text = $"{min}";
                AverageLabel.Text = $"{average}";
                TotalLabel.Text = $"{sum}";

                ErrorMessage.CssClass = ""; // Remove the error class if input is valid
                // Since the input is correct and results are displayed, ensure that the error message is not visible
                ErrorMessage.Visible = false;
            }
            else
            {
                // Display error
                ErrorMessage.Text = "Error: Please enter valid numbers.";
                ErrorMessage.CssClass = "error"; // Apply the error class to make the text red
                ErrorMessage.Visible = true; // Ensure the error message is visible when there is an error
                MaximumLabel.Text = "";
                MinimumLabel.Text = "";
                AverageLabel.Text = "";
                TotalLabel.Text = "";
            }
        }
    }
}