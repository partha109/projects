﻿using Lab8.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab8
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialize session variable if it doesn't exist
                if (Session["Students"] == null)
                {
                    Session["Students"] = new List<Student>();
                }

                // Bind the session list to the GridView
                BindStudentsGrid();
            }
        }

        protected void AddButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (!string.IsNullOrWhiteSpace(studentName.Text) && studentType.SelectedValue != "")
                {
                    List<Student> students = (List<Student>)Session["Students"] ?? new List<Student>();

                    // Create a student object based on the selected type.
                    Student newStudent = CreateStudent(studentName.Text, studentType.SelectedValue);

                    students.Add(newStudent);

                    Session["SelectedStudentType"] = studentType.SelectedValue; // Update the session

                    BindStudentsGrid(); // Update the GridView

                    // Clear the fields
                    studentName.Text = string.Empty;
                    studentType.SelectedIndex = 0;
                }
            }
        }

        private Student CreateStudent(string name, string type)
        {
            Student student;
            switch (type)
            {
                case "FullTime":
                    student = new FulltimeStudent(name);
                    break;
                case "PartTime":
                    student = new ParttimeStudent(name);
                    break;
                case "Coop":
                    student = new CoopStudent(name);
                    break;
                default:
                    throw new ArgumentException("Invalid student type.");
            }
            student.StudentType = type; // Set the type here
            return student;
        }


        private void BindStudentsGrid()
        {
            studentsGrid.DataSource = Session["Students"] as List<Student>;
            studentsGrid.DataBind();
        }
    }
}