﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab8.Models
{
    public class Course
    {
        // Readonly properties
        public string Code { get; set; }
        public string Title { get; set; }

        // Read and write property
        public int WeeklyHours { get; set; }

        // Constructor
        public Course(string code, string title, int weeklyHours)
        {
            Code = code;
            Title = title;
            WeeklyHours = weeklyHours;
        }
    }
}