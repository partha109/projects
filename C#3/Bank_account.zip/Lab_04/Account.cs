﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_04
{
    internal class Account
    {
         // Properties with appropriate getters and private setters
        public int AccountNumber { get; private set; }
        public string OwnerName { get; private set; }
        public decimal Balance { get; private set; }
        public decimal MonthlyDepositAmount { get; private set; }

        // Static properties
        public static decimal MonthlyFee { get; set; } = 4.0m;
        public static decimal MonthlyInterestRate { get; set; } = 0.0025m;
        public static decimal MinimumInitialBalance { get; set; } = 1000m;
        public static decimal MinimumMonthlyDeposit { get; set; } = 50m;

        // Constructor
        public Account(string ownerName, decimal initialDeposit, decimal monthlyDeposit)
        {
            AccountNumber = new Random().Next(10000) + 90000; // Generates a random number between 90000 and 99999
            OwnerName = ownerName;
            Balance = initialDeposit;
            MonthlyDepositAmount = monthlyDeposit;
        }

        // Methods for deposit and withdrawal with validation
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Deposit amount must be positive.");
            }
            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdrawal amount must be positive.");
            }
            if (Balance < amount)
            {
                throw new InvalidOperationException("Not enough funds to withdraw.");
            }
            Balance -= amount;
        }

        public void UpdateBalanceForMonth()
        {
            Withdraw(Account.MonthlyFee);
            Deposit(Balance * Account.MonthlyInterestRate);
            Deposit(MonthlyDepositAmount);
        }
        public void UpdateBalanceForMonths(int numberOfMonths)
        {
            for (int i = 0; i < numberOfMonths; i++)
            {
                UpdateBalanceForMonth();
            }
        }

    }
}
